# Clinic Appointment Scheduling Mobile Application

A complete Android Studio project for a Clinic Appointment Scheduling system, built with **Java** and **SQLite**.

**Design:** Premium Healthcare theme — deep navy blue with gold accents.

---

## 📱 Features

### Patient features
- Register and login (passwords hashed with SHA-256)
- Hero-styled dashboard with quick action cards
- **Browse doctors** — see all specialists in a beautiful list with avatars, ratings, and experience
- **Search doctors** — filter by name or specialty in real-time
- **Doctor profile** — view stats (patients, years, reviews), about section, and book directly from profile
- **Visual time slot picker** — tap day pills (next 14 days) and time chips (visual buttons)
- **Reason for visit** — describe the concern
- **My Appointments** — view, cancel, filter by status (All/Pending/Confirmed/Completed/Cancelled), search by doctor
- **Local appointment reminders** — notification fires 1 hour before appointment (works offline)
- Edit profile (name, phone)

### Admin / Staff features
- Separate **"Admin Access"** login button
- Default admin: `admin@clinic.com` / `admin123`
- Admin dashboard with live stats
- **Manage Appointments** — confirm, complete, cancel, delete with status filter and search
- **Manage Patients** — view all registered patients with search by name or email

### Pre-loaded sample data
- 5 doctors with specializations (General Medicine, Pediatrics, Dermatology, Cardiology, Dentistry)
- Each doctor has stats (patients seen, years experience, reviews count, rating)

---

## 🛠 How to open in Android Studio

1. Extract the project to a folder.
2. **File → Open** → select the extracted `ClinicApp` folder.
3. Click **Trust Project**.
4. Wait for Gradle sync (downloads dependencies).
5. Click the green **Run ▶** on phone or emulator.

---

## 🔑 Default login credentials

**Admin** (use the "🔒 Admin Access" button)
- Email: `admin@clinic.com`
- Password: `admin123`

**Patient**: register a fresh account.

---

## 🎨 Design system

- Primary deep blue (`#0A2540`) and gold (`#C9A961`)
- Hero headers with curved bottom edges
- Card-based layouts with subtle shadows
- Visual chip selectors (day pills, time slot pills, filter chips)
- Status pills with semantic colors
- Color-coded circular icon badges

---

## ✅ Honors project delimitations

- Android only (minSdk 24, Android 7.0+)
- No online payment
- No video consultation
- Internet not required (SQLite local + local notifications)
- Scheduling-focused only

---

## 📂 New activities in this version

- `DoctorListActivity` — searchable doctor list with avatar circles
- `DoctorProfileActivity` — doctor stats, visual day/time picker, in-place booking

---

## 🖼 Optional: Add a clinic photo background

To add a real clinic photo as faded background:
1. Place `bg_clinic.jpg` in `app/src/main/res/drawable/`
2. Open `app/src/main/res/drawable/bg_screen_with_photo.xml`
3. Replace its content with the layer-list version (commented inside the file)
