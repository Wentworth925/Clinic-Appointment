package com.example.clinicapp.receivers;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import androidx.core.app.NotificationCompat;

import com.example.clinicapp.R;
import com.example.clinicapp.utils.NotificationHelper;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        int apptId = intent.getIntExtra("appt_id", 0);
        String doctor = intent.getStringExtra("doctor");
        String date = intent.getStringExtra("date");
        String time = intent.getStringExtra("time");

        NotificationHelper.createChannel(context);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(
                context, NotificationHelper.CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Upcoming Appointment Reminder")
                .setContentText("You have an appointment with " + doctor +
                        " on " + date + " at " + time)
                .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText("Reminder: Your appointment with " + doctor +
                                " is scheduled on " + date + " at " + time +
                                ". Please arrive 10 minutes early."))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);

        NotificationManager nm = (NotificationManager)
                context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify(apptId, builder.build());
        }
    }
}
