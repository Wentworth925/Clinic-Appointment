package com.example.clinicapp.utils;

import android.content.Context;
import android.content.SharedPreferences;

public class SessionManager {
    private static final String PREF_NAME = "clinic_session";
    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_USER_NAME = "user_name";
    private static final String KEY_USER_EMAIL = "user_email";
    private static final String KEY_USER_ROLE = "user_role";
    private static final String KEY_LOGGED_IN = "logged_in";
    private static final String KEY_NOTIF_ENABLED = "notif_enabled";
    private static final String KEY_NOTIF_MINUTES_BEFORE = "notif_minutes_before";

    private final SharedPreferences prefs;

    public SessionManager(Context context) {
        prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public void createSession(int id, String name, String email, String role) {
        SharedPreferences.Editor e = prefs.edit();
        e.putInt(KEY_USER_ID, id);
        e.putString(KEY_USER_NAME, name);
        e.putString(KEY_USER_EMAIL, email);
        e.putString(KEY_USER_ROLE, role);
        e.putBoolean(KEY_LOGGED_IN, true);
        e.apply();
    }

    public boolean isLoggedIn() {
        return prefs.getBoolean(KEY_LOGGED_IN, false);
    }

    public int getUserId() { return prefs.getInt(KEY_USER_ID, -1); }
    public String getUserName() { return prefs.getString(KEY_USER_NAME, ""); }
    public String getUserEmail() { return prefs.getString(KEY_USER_EMAIL, ""); }
    public String getUserRole() { return prefs.getString(KEY_USER_ROLE, "patient"); }
    public boolean isAdmin() { return "admin".equals(getUserRole()); }

    // Notification settings (persist across all users - app-wide)
    public boolean isNotificationsEnabled() {
        return prefs.getBoolean(KEY_NOTIF_ENABLED, true);
    }

    public void setNotificationsEnabled(boolean enabled) {
        prefs.edit().putBoolean(KEY_NOTIF_ENABLED, enabled).apply();
    }

    public int getReminderMinutesBefore() {
        return prefs.getInt(KEY_NOTIF_MINUTES_BEFORE, 60);
    }

    public void setReminderMinutesBefore(int minutes) {
        prefs.edit().putInt(KEY_NOTIF_MINUTES_BEFORE, minutes).apply();
    }

    public void logout() {
        // Clear user session but keep app-wide settings
        boolean notifEnabled = isNotificationsEnabled();
        int reminderMinutes = getReminderMinutesBefore();
        prefs.edit().clear()
                .putBoolean(KEY_NOTIF_ENABLED, notifEnabled)
                .putInt(KEY_NOTIF_MINUTES_BEFORE, reminderMinutes)
                .apply();
    }
}
