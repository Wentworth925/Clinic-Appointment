package com.example.clinicapp.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.clinicapp.R;
import com.example.clinicapp.models.Doctor;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DoctorAdapter extends RecyclerView.Adapter<DoctorAdapter.VH> {

    public interface OnDoctorClick {
        void onClick(Doctor doctor);
    }

    private final List<Doctor> originalList;
    private final List<Doctor> filteredList;
    private final OnDoctorClick listener;

    public DoctorAdapter(List<Doctor> doctors, OnDoctorClick listener) {
        this.originalList = new ArrayList<>(doctors);
        this.filteredList = new ArrayList<>(doctors);
        this.listener = listener;
    }

    public void filter(String query) {
        filteredList.clear();
        if (query == null || query.trim().isEmpty()) {
            filteredList.addAll(originalList);
        } else {
            String q = query.toLowerCase(Locale.getDefault()).trim();
            for (Doctor d : originalList) {
                if (d.getName().toLowerCase(Locale.getDefault()).contains(q) ||
                        d.getSpecialization().toLowerCase(Locale.getDefault()).contains(q)) {
                    filteredList.add(d);
                }
            }
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_doctor, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Doctor d = filteredList.get(position);
        h.tvInitials.setText(d.getInitials());
        h.tvName.setText(d.getName());
        h.tvSpec.setText(d.getSpecialization());
        h.tvRating.setText(String.format(Locale.getDefault(), "%.1f", d.getRating()));
        h.tvExperience.setText(d.getYearsExperience() + "+ yrs exp");

        h.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onClick(d);
        });
    }

    @Override
    public int getItemCount() {
        return filteredList.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvInitials, tvName, tvSpec, tvRating, tvExperience;

        VH(@NonNull View itemView) {
            super(itemView);
            tvInitials = itemView.findViewById(R.id.tvInitials);
            tvName = itemView.findViewById(R.id.tvDoctorName);
            tvSpec = itemView.findViewById(R.id.tvSpec);
            tvRating = itemView.findViewById(R.id.tvRating);
            tvExperience = itemView.findViewById(R.id.tvExperience);
        }
    }
}
