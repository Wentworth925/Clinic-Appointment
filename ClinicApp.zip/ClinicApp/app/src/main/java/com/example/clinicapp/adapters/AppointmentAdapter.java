package com.example.clinicapp.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.clinicapp.R;
import com.example.clinicapp.models.Appointment;

import java.util.List;

public class AppointmentAdapter extends RecyclerView.Adapter<AppointmentAdapter.VH> {

    public interface OnItemClick {
        void onClick(Appointment a);
    }

    private final List<Appointment> items;
    private final OnItemClick listener;
    private final boolean showPatientName;

    public AppointmentAdapter(List<Appointment> items, boolean showPatientName,
                              OnItemClick listener) {
        this.items = items;
        this.listener = listener;
        this.showPatientName = showPatientName;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_appointment, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        Appointment a = items.get(position);
        h.tvDoctor.setText(a.getDoctorName());
        h.tvSpec.setText(a.getSpecialization());
        h.tvDate.setText(a.getDate() + " • " + a.getTime());
        h.tvReason.setText(a.getReason());
        h.tvStatus.setText(a.getStatus().toUpperCase());

        if (showPatientName) {
            h.tvPatient.setVisibility(View.VISIBLE);
            h.tvPatient.setText("👤  " + a.getPatientName());
        } else {
            h.tvPatient.setVisibility(View.GONE);
        }

        int textColor;
        int pillBg;
        switch (a.getStatus()) {
            case Appointment.STATUS_CONFIRMED:
                textColor = R.color.status_confirmed;
                pillBg = R.drawable.pill_confirmed;
                break;
            case Appointment.STATUS_CANCELLED:
                textColor = R.color.status_cancelled;
                pillBg = R.drawable.pill_cancelled;
                break;
            case Appointment.STATUS_COMPLETED:
                textColor = R.color.status_completed;
                pillBg = R.drawable.pill_completed;
                break;
            default:
                textColor = R.color.status_pending;
                pillBg = R.drawable.pill_pending;
        }
        h.tvStatus.setTextColor(ContextCompat.getColor(h.itemView.getContext(), textColor));
        h.tvStatus.setBackgroundResource(pillBg);

        h.itemView.setOnClickListener(v -> {
            if (listener != null) listener.onClick(a);
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvDoctor, tvSpec, tvDate, tvReason, tvStatus, tvPatient;

        VH(@NonNull View itemView) {
            super(itemView);
            tvDoctor = itemView.findViewById(R.id.tvDoctor);
            tvSpec = itemView.findViewById(R.id.tvSpec);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvReason = itemView.findViewById(R.id.tvReason);
            tvStatus = itemView.findViewById(R.id.tvStatus);
            tvPatient = itemView.findViewById(R.id.tvPatient);
        }
    }
}
