package com.example.clinicapp.utils;

import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.example.clinicapp.models.Appointment;
import com.example.clinicapp.receivers.ReminderReceiver;

public class NotificationHelper {
    public static final String CHANNEL_ID = "clinic_reminders";
    public static final String CHANNEL_NAME = "Appointment Reminders";

    public static void createChannel(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Reminders for upcoming clinic appointments");
            NotificationManager nm = context.getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    /**
     * Schedules a reminder before the appointment using user's preferred timing.
     * Respects the notifications-enabled setting.
     */
    public static void scheduleReminder(Context context, Appointment appt) {
        SessionManager session = new SessionManager(context);
        if (!session.isNotificationsEnabled()) return;

        int minutesBefore = session.getReminderMinutesBefore();
        long reminderTime = appt.getTimestamp() - (minutesBefore * 60 * 1000L);
        long now = System.currentTimeMillis();
        if (reminderTime < now) reminderTime = now + 5000;
        if (appt.getTimestamp() < now) return;

        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.putExtra("appt_id", appt.getId());
        intent.putExtra("doctor", appt.getDoctorName());
        intent.putExtra("date", appt.getDate());
        intent.putExtra("time", appt.getTime());

        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pi = PendingIntent.getBroadcast(context, appt.getId(), intent, flags);

        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !am.canScheduleExactAlarms()) {
                am.set(AlarmManager.RTC_WAKEUP, reminderTime, pi);
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminderTime, pi);
            }
        } catch (SecurityException e) {
            am.set(AlarmManager.RTC_WAKEUP, reminderTime, pi);
        }
    }

    public static void cancelReminder(Context context, int apptId) {
        Intent intent = new Intent(context, ReminderReceiver.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pi = PendingIntent.getBroadcast(context, apptId, intent, flags);
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (am != null) am.cancel(pi);
    }
}
