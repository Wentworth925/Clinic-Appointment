package com.example.clinicapp.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.clinicapp.models.Appointment;
import com.example.clinicapp.models.Doctor;
import com.example.clinicapp.models.User;
import com.example.clinicapp.utils.PasswordUtils;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "clinic_scheduler.db";
    private static final int DB_VERSION = 2;

    // Users table
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "id";
    private static final String COL_USER_NAME = "full_name";
    private static final String COL_USER_EMAIL = "email";
    private static final String COL_USER_PHONE = "phone";
    private static final String COL_USER_PASSWORD = "password";
    private static final String COL_USER_ROLE = "role";
    private static final String COL_USER_AGE = "age";
    private static final String COL_USER_GENDER = "gender";
    private static final String COL_USER_ADDRESS = "address";

    // Doctors table
    private static final String TABLE_DOCTORS = "doctors";
    private static final String COL_DOC_ID = "id";
    private static final String COL_DOC_NAME = "name";
    private static final String COL_DOC_SPEC = "specialization";
    private static final String COL_DOC_DAYS = "available_days";

    // Appointments table
    private static final String TABLE_APPOINTMENTS = "appointments";
    private static final String COL_APPT_ID = "id";
    private static final String COL_APPT_PATIENT_ID = "patient_id";
    private static final String COL_APPT_PATIENT_NAME = "patient_name";
    private static final String COL_APPT_DOCTOR = "doctor_name";
    private static final String COL_APPT_SPEC = "specialization";
    private static final String COL_APPT_DATE = "date";
    private static final String COL_APPT_TIME = "time";
    private static final String COL_APPT_REASON = "reason";
    private static final String COL_APPT_SYMPTOMS = "symptoms";
    private static final String COL_APPT_STATUS = "status";
    private static final String COL_APPT_TIMESTAMP = "timestamp";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsers = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USER_NAME + " TEXT NOT NULL, " +
                COL_USER_EMAIL + " TEXT UNIQUE NOT NULL, " +
                COL_USER_PHONE + " TEXT, " +
                COL_USER_PASSWORD + " TEXT NOT NULL, " +
                COL_USER_ROLE + " TEXT NOT NULL DEFAULT 'patient', " +
                COL_USER_AGE + " INTEGER DEFAULT 0, " +
                COL_USER_GENDER + " TEXT DEFAULT '', " +
                COL_USER_ADDRESS + " TEXT DEFAULT '')";
        db.execSQL(createUsers);

        String createDoctors = "CREATE TABLE " + TABLE_DOCTORS + " (" +
                COL_DOC_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_DOC_NAME + " TEXT NOT NULL, " +
                COL_DOC_SPEC + " TEXT NOT NULL, " +
                COL_DOC_DAYS + " TEXT)";
        db.execSQL(createDoctors);

        String createAppointments = "CREATE TABLE " + TABLE_APPOINTMENTS + " (" +
                COL_APPT_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_APPT_PATIENT_ID + " INTEGER NOT NULL, " +
                COL_APPT_PATIENT_NAME + " TEXT, " +
                COL_APPT_DOCTOR + " TEXT NOT NULL, " +
                COL_APPT_SPEC + " TEXT, " +
                COL_APPT_DATE + " TEXT NOT NULL, " +
                COL_APPT_TIME + " TEXT NOT NULL, " +
                COL_APPT_REASON + " TEXT, " +
                COL_APPT_SYMPTOMS + " TEXT DEFAULT '', " +
                COL_APPT_STATUS + " TEXT DEFAULT 'Pending', " +
                COL_APPT_TIMESTAMP + " INTEGER, " +
                "FOREIGN KEY(" + COL_APPT_PATIENT_ID + ") REFERENCES " +
                TABLE_USERS + "(" + COL_USER_ID + "))";
        db.execSQL(createAppointments);

        seedInitialData(db);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Safe migration: add new columns to existing tables without losing data
        if (oldVersion < 2) {
            try {
                db.execSQL("ALTER TABLE " + TABLE_USERS + " ADD COLUMN " + COL_USER_AGE + " INTEGER DEFAULT 0");
            } catch (Exception ignored) {}
            try {
                db.execSQL("ALTER TABLE " + TABLE_USERS + " ADD COLUMN " + COL_USER_GENDER + " TEXT DEFAULT ''");
            } catch (Exception ignored) {}
            try {
                db.execSQL("ALTER TABLE " + TABLE_USERS + " ADD COLUMN " + COL_USER_ADDRESS + " TEXT DEFAULT ''");
            } catch (Exception ignored) {}
            try {
                db.execSQL("ALTER TABLE " + TABLE_APPOINTMENTS + " ADD COLUMN " + COL_APPT_SYMPTOMS + " TEXT DEFAULT ''");
            } catch (Exception ignored) {}
        }
    }

    private void seedInitialData(SQLiteDatabase db) {
        ContentValues admin = new ContentValues();
        admin.put(COL_USER_NAME, "Clinic Admin");
        admin.put(COL_USER_EMAIL, "admin@clinic.com");
        admin.put(COL_USER_PHONE, "0000000000");
        admin.put(COL_USER_PASSWORD, PasswordUtils.hash("admin123"));
        admin.put(COL_USER_ROLE, "admin");
        db.insert(TABLE_USERS, null, admin);

        String[][] doctors = {
                {"Dr. Maria Santos", "General Medicine", "Mon,Tue,Wed,Thu,Fri"},
                {"Dr. John Reyes", "Pediatrics", "Mon,Wed,Fri"},
                {"Dr. Anna Cruz", "Dermatology", "Tue,Thu,Sat"},
                {"Dr. Carlos Lim", "Cardiology", "Mon,Tue,Thu"},
                {"Dr. Sophia Garcia", "Dentistry", "Mon,Wed,Fri,Sat"}
        };
        for (String[] d : doctors) {
            ContentValues v = new ContentValues();
            v.put(COL_DOC_NAME, d[0]);
            v.put(COL_DOC_SPEC, d[1]);
            v.put(COL_DOC_DAYS, d[2]);
            db.insert(TABLE_DOCTORS, null, v);
        }
    }

    // ============ USER METHODS ============
    public long registerUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put(COL_USER_NAME, user.getFullName());
        v.put(COL_USER_EMAIL, user.getEmail().toLowerCase().trim());
        v.put(COL_USER_PHONE, user.getPhone());
        v.put(COL_USER_PASSWORD, PasswordUtils.hash(user.getPassword()));
        v.put(COL_USER_ROLE, user.getRole() == null ? "patient" : user.getRole());
        v.put(COL_USER_AGE, user.getAge());
        v.put(COL_USER_GENDER, user.getGender() == null ? "" : user.getGender());
        v.put(COL_USER_ADDRESS, user.getAddress() == null ? "" : user.getAddress());
        long result = db.insert(TABLE_USERS, null, v);
        db.close();
        return result;
    }

    public User loginUser(String email, String password) {
        SQLiteDatabase db = getReadableDatabase();
        String hashed = PasswordUtils.hash(password);
        Cursor c = db.query(TABLE_USERS, null,
                COL_USER_EMAIL + "=? AND " + COL_USER_PASSWORD + "=?",
                new String[]{email.toLowerCase().trim(), hashed},
                null, null, null);
        User user = null;
        if (c.moveToFirst()) {
            user = cursorToUser(c);
        }
        c.close();
        db.close();
        return user;
    }

    public boolean emailExists(String email) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_USERS, new String[]{COL_USER_ID},
                COL_USER_EMAIL + "=?", new String[]{email.toLowerCase().trim()},
                null, null, null);
        boolean exists = c.getCount() > 0;
        c.close();
        db.close();
        return exists;
    }

    public User getUserById(int userId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_USERS, null,
                COL_USER_ID + "=?", new String[]{String.valueOf(userId)},
                null, null, null);
        User u = null;
        if (c.moveToFirst()) u = cursorToUser(c);
        c.close();
        db.close();
        return u;
    }

    public List<User> getAllPatients() {
        List<User> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_USERS, null,
                COL_USER_ROLE + "=?", new String[]{"patient"},
                null, null, COL_USER_NAME + " ASC");
        while (c.moveToNext()) list.add(cursorToUser(c));
        c.close();
        db.close();
        return list;
    }

    public boolean updateUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put(COL_USER_NAME, user.getFullName());
        v.put(COL_USER_PHONE, user.getPhone());
        v.put(COL_USER_AGE, user.getAge());
        v.put(COL_USER_GENDER, user.getGender() == null ? "" : user.getGender());
        v.put(COL_USER_ADDRESS, user.getAddress() == null ? "" : user.getAddress());
        int rows = db.update(TABLE_USERS, v, COL_USER_ID + "=?",
                new String[]{String.valueOf(user.getId())});
        db.close();
        return rows > 0;
    }

    public boolean deletePatient(int userId) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_APPOINTMENTS, COL_APPT_PATIENT_ID + "=?",
                new String[]{String.valueOf(userId)});
        int rows = db.delete(TABLE_USERS, COL_USER_ID + "=?",
                new String[]{String.valueOf(userId)});
        db.close();
        return rows > 0;
    }

    public boolean updatePassword(String email, String newPassword) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put(COL_USER_PASSWORD, PasswordUtils.hash(newPassword));
        int rows = db.update(TABLE_USERS, v,
                COL_USER_EMAIL + "=? AND " + COL_USER_ROLE + "=?",
                new String[]{email.toLowerCase().trim(), "patient"});
        db.close();
        return rows > 0;
    }

    private User cursorToUser(Cursor c) {
        User u = new User();
        u.setId(c.getInt(c.getColumnIndexOrThrow(COL_USER_ID)));
        u.setFullName(c.getString(c.getColumnIndexOrThrow(COL_USER_NAME)));
        u.setEmail(c.getString(c.getColumnIndexOrThrow(COL_USER_EMAIL)));
        u.setPhone(c.getString(c.getColumnIndexOrThrow(COL_USER_PHONE)));
        u.setPassword(c.getString(c.getColumnIndexOrThrow(COL_USER_PASSWORD)));
        u.setRole(c.getString(c.getColumnIndexOrThrow(COL_USER_ROLE)));
        int ageIdx = c.getColumnIndex(COL_USER_AGE);
        if (ageIdx >= 0) u.setAge(c.getInt(ageIdx));
        int genderIdx = c.getColumnIndex(COL_USER_GENDER);
        if (genderIdx >= 0) u.setGender(c.getString(genderIdx));
        int addressIdx = c.getColumnIndex(COL_USER_ADDRESS);
        if (addressIdx >= 0) u.setAddress(c.getString(addressIdx));
        return u;
    }

    // ============ DOCTOR METHODS ============
    public List<Doctor> getAllDoctors() {
        List<Doctor> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_DOCTORS, null, null, null, null, null,
                COL_DOC_NAME + " ASC");
        while (c.moveToNext()) {
            list.add(new Doctor(
                    c.getInt(c.getColumnIndexOrThrow(COL_DOC_ID)),
                    c.getString(c.getColumnIndexOrThrow(COL_DOC_NAME)),
                    c.getString(c.getColumnIndexOrThrow(COL_DOC_SPEC)),
                    c.getString(c.getColumnIndexOrThrow(COL_DOC_DAYS))
            ));
        }
        c.close();
        db.close();
        return list;
    }

    // ============ APPOINTMENT METHODS ============
    public long bookAppointment(Appointment appt) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put(COL_APPT_PATIENT_ID, appt.getPatientId());
        v.put(COL_APPT_PATIENT_NAME, appt.getPatientName());
        v.put(COL_APPT_DOCTOR, appt.getDoctorName());
        v.put(COL_APPT_SPEC, appt.getSpecialization());
        v.put(COL_APPT_DATE, appt.getDate());
        v.put(COL_APPT_TIME, appt.getTime());
        v.put(COL_APPT_REASON, appt.getReason());
        v.put(COL_APPT_SYMPTOMS, appt.getSymptoms() == null ? "" : appt.getSymptoms());
        v.put(COL_APPT_STATUS, appt.getStatus());
        v.put(COL_APPT_TIMESTAMP, appt.getTimestamp());
        long id = db.insert(TABLE_APPOINTMENTS, null, v);
        db.close();
        return id;
    }

    public boolean isSlotTaken(String doctorName, String date, String time) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_APPOINTMENTS, new String[]{COL_APPT_ID},
                COL_APPT_DOCTOR + "=? AND " + COL_APPT_DATE + "=? AND " +
                        COL_APPT_TIME + "=? AND " + COL_APPT_STATUS + "!=?",
                new String[]{doctorName, date, time, Appointment.STATUS_CANCELLED},
                null, null, null);
        boolean taken = c.getCount() > 0;
        c.close();
        db.close();
        return taken;
    }

    public List<String> getBookedTimes(String doctorName, String date) {
        List<String> times = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_APPOINTMENTS, new String[]{COL_APPT_TIME},
                COL_APPT_DOCTOR + "=? AND " + COL_APPT_DATE + "=? AND " +
                        COL_APPT_STATUS + "!=?",
                new String[]{doctorName, date, Appointment.STATUS_CANCELLED},
                null, null, null);
        while (c.moveToNext()) {
            times.add(c.getString(0));
        }
        c.close();
        db.close();
        return times;
    }

    public List<Appointment> getAppointmentsForPatient(int patientId) {
        List<Appointment> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_APPOINTMENTS, null,
                COL_APPT_PATIENT_ID + "=?", new String[]{String.valueOf(patientId)},
                null, null, COL_APPT_TIMESTAMP + " DESC");
        while (c.moveToNext()) list.add(cursorToAppointment(c));
        c.close();
        db.close();
        return list;
    }

    public int countAppointmentsByStatus(int patientId, String status) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_APPOINTMENTS, new String[]{COL_APPT_ID},
                COL_APPT_PATIENT_ID + "=? AND " + COL_APPT_STATUS + "=?",
                new String[]{String.valueOf(patientId), status},
                null, null, null);
        int count = c.getCount();
        c.close();
        db.close();
        return count;
    }

    public int countUpcomingForPatient(int patientId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_APPOINTMENTS, new String[]{COL_APPT_ID},
                COL_APPT_PATIENT_ID + "=? AND " + COL_APPT_TIMESTAMP + ">? AND " +
                        COL_APPT_STATUS + "!=?",
                new String[]{String.valueOf(patientId),
                        String.valueOf(System.currentTimeMillis()),
                        Appointment.STATUS_CANCELLED},
                null, null, null);
        int count = c.getCount();
        c.close();
        db.close();
        return count;
    }

    public Appointment getNextAppointmentForPatient(int patientId) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_APPOINTMENTS, null,
                COL_APPT_PATIENT_ID + "=? AND " + COL_APPT_TIMESTAMP + ">? AND " +
                        COL_APPT_STATUS + "!=?",
                new String[]{String.valueOf(patientId),
                        String.valueOf(System.currentTimeMillis()),
                        Appointment.STATUS_CANCELLED},
                null, null, COL_APPT_TIMESTAMP + " ASC", "1");
        Appointment a = null;
        if (c.moveToFirst()) a = cursorToAppointment(c);
        c.close();
        db.close();
        return a;
    }

    public List<Appointment> getAllAppointments() {
        List<Appointment> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE_APPOINTMENTS, null, null, null, null, null,
                COL_APPT_TIMESTAMP + " DESC");
        while (c.moveToNext()) list.add(cursorToAppointment(c));
        c.close();
        db.close();
        return list;
    }

    public boolean updateAppointmentStatus(int apptId, String status) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put(COL_APPT_STATUS, status);
        int rows = db.update(TABLE_APPOINTMENTS, v, COL_APPT_ID + "=?",
                new String[]{String.valueOf(apptId)});
        db.close();
        return rows > 0;
    }

    public boolean deleteAppointment(int apptId) {
        SQLiteDatabase db = getWritableDatabase();
        int rows = db.delete(TABLE_APPOINTMENTS, COL_APPT_ID + "=?",
                new String[]{String.valueOf(apptId)});
        db.close();
        return rows > 0;
    }

    private Appointment cursorToAppointment(Cursor c) {
        Appointment a = new Appointment();
        a.setId(c.getInt(c.getColumnIndexOrThrow(COL_APPT_ID)));
        a.setPatientId(c.getInt(c.getColumnIndexOrThrow(COL_APPT_PATIENT_ID)));
        a.setPatientName(c.getString(c.getColumnIndexOrThrow(COL_APPT_PATIENT_NAME)));
        a.setDoctorName(c.getString(c.getColumnIndexOrThrow(COL_APPT_DOCTOR)));
        a.setSpecialization(c.getString(c.getColumnIndexOrThrow(COL_APPT_SPEC)));
        a.setDate(c.getString(c.getColumnIndexOrThrow(COL_APPT_DATE)));
        a.setTime(c.getString(c.getColumnIndexOrThrow(COL_APPT_TIME)));
        a.setReason(c.getString(c.getColumnIndexOrThrow(COL_APPT_REASON)));
        a.setStatus(c.getString(c.getColumnIndexOrThrow(COL_APPT_STATUS)));
        a.setTimestamp(c.getLong(c.getColumnIndexOrThrow(COL_APPT_TIMESTAMP)));
        int symptomsIdx = c.getColumnIndex(COL_APPT_SYMPTOMS);
        if (symptomsIdx >= 0) a.setSymptoms(c.getString(symptomsIdx));
        return a;
    }
}
