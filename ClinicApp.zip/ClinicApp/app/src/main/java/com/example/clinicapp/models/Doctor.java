package com.example.clinicapp.models;

import java.io.Serializable;

public class Doctor implements Serializable {
    private int id;
    private String name;
    private String specialization;
    private String availableDays;
    private int patientsCount;
    private int yearsExperience;
    private int reviewsCount;
    private float rating;

    public Doctor() {}

    public Doctor(int id, String name, String specialization, String availableDays) {
        this.id = id;
        this.name = name;
        this.specialization = specialization;
        this.availableDays = availableDays;
        // Generated stats for demo (deterministic per id)
        this.patientsCount = 250 + (id * 47) % 200;
        this.yearsExperience = 5 + (id * 3) % 20;
        this.reviewsCount = 120 + (id * 31) % 200;
        this.rating = 4.5f + ((id % 5) * 0.1f);
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getSpecialization() { return specialization; }
    public String getAvailableDays() { return availableDays; }
    public int getPatientsCount() { return patientsCount; }
    public int getYearsExperience() { return yearsExperience; }
    public int getReviewsCount() { return reviewsCount; }
    public float getRating() { return rating; }

    public String getAbout() {
        return name + " is a highly experienced " + specialization.toLowerCase() +
                " specialist with " + yearsExperience + "+ years of practice. " +
                "Known for compassionate patient care and accurate diagnoses, " +
                name + " is available for consultations during clinic hours and " +
                "is committed to providing the highest quality medical service.";
    }

    public String getInitials() {
        if (name == null || name.isEmpty()) return "?";
        String cleaned = name.replace("Dr.", "").trim();
        String[] parts = cleaned.split("\\s+");
        if (parts.length >= 2) {
            return ("" + parts[0].charAt(0) + parts[1].charAt(0)).toUpperCase();
        }
        return parts[0].substring(0, Math.min(2, parts[0].length())).toUpperCase();
    }

    @Override
    public String toString() {
        return name + " (" + specialization + ")";
    }
}
