package com.example.clinicapp.utils;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.example.clinicapp.R;

public class ModernDialog {

    public enum Type {
        SUCCESS, INFO, WARNING, ERROR, CONFIRM
    }

    public interface OnButtonClick {
        void onClick();
    }

    public interface OnActionSelected {
        void onSelected(int index);
    }

    private final Context context;
    private final Dialog dialog;
    private final TextView tvTitle, tvMessage, tvIcon;
    private final View iconBg;
    private final Button btnPositive, btnNegative;

    private OnButtonClick positiveListener;
    private OnButtonClick negativeListener;

    public ModernDialog(Context context) {
        this.context = context;
        dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        View view = LayoutInflater.from(context).inflate(R.layout.dialog_modern, null);
        dialog.setContentView(view);

        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        tvTitle = view.findViewById(R.id.tvTitle);
        tvMessage = view.findViewById(R.id.tvMessage);
        tvIcon = view.findViewById(R.id.tvIcon);
        iconBg = view.findViewById(R.id.iconBg);
        btnPositive = view.findViewById(R.id.btnPositive);
        btnNegative = view.findViewById(R.id.btnNegative);

        btnPositive.setOnClickListener(v -> {
            dialog.dismiss();
            if (positiveListener != null) positiveListener.onClick();
        });
        btnNegative.setOnClickListener(v -> {
            dialog.dismiss();
            if (negativeListener != null) negativeListener.onClick();
        });
    }

    public ModernDialog setTitle(String title) {
        tvTitle.setText(title);
        return this;
    }

    public ModernDialog setMessage(String message) {
        tvMessage.setText(message);
        return this;
    }

    public ModernDialog setType(Type type) {
        switch (type) {
            case SUCCESS:
                tvIcon.setText("✓");
                tvIcon.setTextColor(ContextCompat.getColor(context, R.color.status_confirmed));
                iconBg.setBackgroundResource(R.drawable.badge_green);
                break;
            case WARNING:
                tvIcon.setText("⚠");
                tvIcon.setTextColor(ContextCompat.getColor(context, R.color.status_pending));
                iconBg.setBackgroundResource(R.drawable.badge_gold);
                break;
            case ERROR:
                tvIcon.setText("✕");
                tvIcon.setTextColor(ContextCompat.getColor(context, R.color.status_cancelled));
                iconBg.setBackgroundResource(R.drawable.badge_red);
                break;
            case CONFIRM:
                tvIcon.setText("?");
                tvIcon.setTextColor(ContextCompat.getColor(context, R.color.primary));
                iconBg.setBackgroundResource(R.drawable.badge_purple);
                break;
            case INFO:
            default:
                tvIcon.setText("i");
                tvIcon.setTextColor(ContextCompat.getColor(context, R.color.primary));
                iconBg.setBackgroundResource(R.drawable.badge_blue);
                break;
        }
        return this;
    }

    public ModernDialog setPositiveButton(String text, OnButtonClick listener) {
        btnPositive.setText(text);
        btnPositive.setVisibility(View.VISIBLE);
        positiveListener = listener;
        return this;
    }

    public ModernDialog setNegativeButton(String text, OnButtonClick listener) {
        btnNegative.setText(text);
        btnNegative.setVisibility(View.VISIBLE);
        negativeListener = listener;
        return this;
    }

    public ModernDialog setCancelable(boolean cancelable) {
        dialog.setCancelable(cancelable);
        return this;
    }

    public void show() {
        dialog.show();
        applyDialogWidth(dialog, context);
    }

    /** Force the dialog window to take 90% of the screen width. */
    private static void applyDialogWidth(Dialog dialog, Context context) {
        Window w = dialog.getWindow();
        if (w == null) return;
        int screenWidth = context.getResources().getDisplayMetrics().widthPixels;
        WindowManager.LayoutParams lp = w.getAttributes();
        lp.width = (int) (screenWidth * 0.9);
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
        w.setAttributes(lp);
    }

    // ============ Convenience static methods ============

    public static void showSuccess(Context context, String title, String message) {
        new ModernDialog(context)
                .setType(Type.SUCCESS)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    public static void showError(Context context, String title, String message) {
        new ModernDialog(context)
                .setType(Type.ERROR)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    public static void showInfo(Context context, String title, String message) {
        new ModernDialog(context)
                .setType(Type.INFO)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    public static void showWarning(Context context, String title, String message) {
        new ModernDialog(context)
                .setType(Type.WARNING)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    public static void showConfirm(Context context, String title, String message,
                                   String positiveText, OnButtonClick onConfirm) {
        new ModernDialog(context)
                .setType(Type.CONFIRM)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(positiveText, onConfirm)
                .setNegativeButton("Cancel", null)
                .show();
    }

    /**
     * Modern action picker. Replaces AlertDialog.setItems() with styled buttons.
     */
    public static void showActionPicker(Context context, String title, String subtitle,
                                        String[] actions, OnActionSelected listener) {
        Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);

        View view = LayoutInflater.from(context).inflate(R.layout.dialog_action_picker, null);
        dialog.setContentView(view);

        Window window = dialog.getWindow();
        if (window != null) {
            window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }

        ((TextView) view.findViewById(R.id.tvTitle)).setText(title);
        TextView tvSubtitle = view.findViewById(R.id.tvSubtitle);
        if (subtitle != null && !subtitle.isEmpty()) {
            tvSubtitle.setText(subtitle);
            tvSubtitle.setVisibility(View.VISIBLE);
        }

        LinearLayout container = view.findViewById(R.id.actionsContainer);
        float density = context.getResources().getDisplayMetrics().density;
        int padH = (int) (16 * density);
        int padV = (int) (14 * density);
        int marginTop = (int) (8 * density);

        for (int i = 0; i < actions.length; i++) {
            final int index = i;
            TextView btn = new TextView(context);
            btn.setText(actions[i]);
            btn.setBackgroundResource(R.drawable.bg_action_row);
            btn.setTextColor(ContextCompat.getColor(context, R.color.text_primary));
            btn.setTextSize(14);
            btn.setTypeface(null, Typeface.BOLD);
            btn.setGravity(Gravity.CENTER);
            btn.setPadding(padH, padV, padH, padV);

            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            if (i > 0) lp.topMargin = marginTop;
            btn.setLayoutParams(lp);

            btn.setOnClickListener(v -> {
                dialog.dismiss();
                if (listener != null) listener.onSelected(index);
            });
            container.addView(btn);
        }

        view.findViewById(R.id.btnClose).setOnClickListener(v -> dialog.dismiss());

        dialog.show();
        applyDialogWidth(dialog, context);
    }
}
